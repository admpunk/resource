
ALLOWED! :) 

Taking screenshots of Minecraft using the Hafen resource pack and posting them . 

Recording videos of Minecraft using the Hafen resource pack and posting them. 

Modifying any textures of the Hafen resource pack for PERSONAL use. 



NOT ALLOWED! :( 

Reposting the Hafen resource pack. 

Using Hafen textures for any other purpose. 

Claiming ownership over the Hafen resource pack. 

Recreating the Steamed Up Rewritten resource pack. 

Using the Hafen resource pack for profit (e.g. adf.ly). 